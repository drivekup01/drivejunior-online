import {getChatGPTUser,chatGPTSignInPath} from "../../chatgpt-auth";
import {quotaStatus} from "../../quota";
export const dynamic="force-dynamic";
export async function GET(){const user=await getChatGPTUser();if(!user)return Response.json({authenticated:false,signInUrl:chatGPTSignInPath("/")},{headers:{"Cache-Control":"no-store"}});try{return Response.json({authenticated:true,name:user.displayName,quota:await quotaStatus(user.userId)},{headers:{"Cache-Control":"no-store"}})}catch{return Response.json({authenticated:true,name:user.displayName,quotaUnavailable:true},{headers:{"Cache-Control":"no-store"}})}}
