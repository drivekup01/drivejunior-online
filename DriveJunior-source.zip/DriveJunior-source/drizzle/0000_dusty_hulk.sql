CREATE TABLE `daily_usage` (
	`day` text NOT NULL,
	`user_id` text NOT NULL,
	`requests` integer DEFAULT 0 NOT NULL,
	`lease_until` integer DEFAULT 0 NOT NULL,
	`lease_token` text DEFAULT '' NOT NULL,
	PRIMARY KEY(`day`, `user_id`)
);
--> statement-breakpoint
CREATE INDEX `daily_usage_day_idx` ON `daily_usage` (`day`);