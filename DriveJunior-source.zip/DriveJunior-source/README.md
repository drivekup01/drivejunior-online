# DriveJunior source

Source only. No API keys or customer images are included.

The production app runs on Sites/Cloudflare Workers with D1 and ChatGPT sign-in. GitHub Pages cannot run its server routes. Install dependencies, create a new Sites project identity for a separate deployment, set OPENAI_API_KEY as a runtime secret, and apply the Drizzle migrations.

Limits: 20 AI requests per authenticated user per Thai calendar day, 200 across the site. Requests that start upstream processing count, including rereads and failures.
